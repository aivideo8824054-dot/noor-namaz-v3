# Noor Namaz V3 (Update 1.4)

This project preserves the existing Noor Namaz interface and features while adding:
- India PIN-code lookup using the India Post PIN API, with State, District and Post Office/Village selection.
- Removal of manual Latitude/Longitude fields from the settings UI; coordinates are resolved internally for prayer-time and Qibla calculations.
- Live Qibla compass using Android WebView device-orientation sensors where supported.
- Gregorian and Hijri date display (existing feature retained).
- Per-prayer Azan time display and minute adjustment controls (existing prayer adjustments retained).

The app requires internet access for PIN lookup. Compass accuracy depends on the handset sensors and calibration. PIN/post-office geocoding may not always return an exact village coordinate; verify prayer timings with a local mosque timetable.

Build: Android Gradle Plugin 8.6.1, compileSdk 35, Java 17, Gradle 8.9 compatible.
