package com.noornamaz.app;
import android.app.*;
import android.content.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
public class AzanService extends Service {
 MediaPlayer player;
 @Override public void onCreate(){ super.onCreate();
   Notification.Builder b;
   if(Build.VERSION.SDK_INT>=26) b=new Notification.Builder(this,"azan"); else b=new Notification.Builder(this).setPriority(Notification.PRIORITY_HIGH);
   Intent stopIntent=new Intent(this,AzanReceiver.class); stopIntent.setAction("com.noornamaz.app.STOP_AZAN");
   PendingIntent stopPi=PendingIntent.getBroadcast(this,991,stopIntent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   Notification n=b.setContentTitle("Noor Namaz").setContentText("Azan chal rahi hai")
    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setOngoing(true)
    .addAction(android.R.drawable.ic_media_pause,"Stop",stopPi).build();
   startForeground(7,n);
 }
 @Override public int onStartCommand(Intent i,int flags,int id){
   try {
     if(player!=null){player.release();player=null;}
     String u=getPreferences().getString("azan_uri",null);
     if(u!=null){ player=new MediaPlayer(); player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()); player.setDataSource(this,Uri.parse(u)); player.setOnCompletionListener(mp->stopSelf()); player.prepare(); player.start(); }
     else { player=MediaPlayer.create(this, android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_RINGTONE)); if(player!=null){player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()); player.setOnCompletionListener(mp->stopSelf()); player.start();} }
   } catch(Exception e){ stopSelf(); }
   return START_NOT_STICKY;
 }
 android.content.SharedPreferences getPreferences(){ return getSharedPreferences("noor",0); }
 @Override public void onDestroy(){ if(player!=null){player.release();player=null;} super.onDestroy(); }
 @Override public android.os.IBinder onBind(Intent i){return null;}
}
