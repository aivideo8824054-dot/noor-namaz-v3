package com.noornamaz.app;
import android.app.*;
import android.content.*;
import android.media.*;
import android.net.Uri;
import android.os.*;
public class AzanService extends Service {
 public static final String ACTION_STOP = "com.noornamaz.app.STOP_AZAN";
 MediaPlayer player;
 @Override public void onCreate(){ super.onCreate();
   Notification.Builder b;
   if(Build.VERSION.SDK_INT>=26) b=new Notification.Builder(this,"azan"); else b=new Notification.Builder(this).setPriority(Notification.PRIORITY_HIGH);
   Intent stopIntent=new Intent(this,AzanService.class).setAction(ACTION_STOP);
   int flags=PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE;
   PendingIntent stopPending=PendingIntent.getService(this,8,stopIntent,flags);
   Notification n=b.setContentTitle("Noor Namaz").setContentText("Azan chal rahi hai — band karne ke liye Stop dabayein")
    .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setOngoing(true)
    .addAction(new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource(this,android.R.drawable.ic_media_pause),"Stop",stopPending).build()).build();
   startForeground(7,n);
 }
 @Override public int onStartCommand(Intent i,int flags,int id){
   if(i!=null && ACTION_STOP.equals(i.getAction())){ stopSelf(); return START_NOT_STICKY; }
   try {
     String u=getPreferences().getString("azan_uri",null);
     if(u!=null){ player=new MediaPlayer(); player.setAudioStreamType(AudioManager.STREAM_ALARM); player.setDataSource(this,Uri.parse(u)); player.setOnCompletionListener(mp->stopSelf()); player.prepare(); player.start(); }
     else { player=MediaPlayer.create(this, android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI); if(player==null) player=MediaPlayer.create(this, android.provider.Settings.System.DEFAULT_RINGTONE_URI); if(player!=null){player.setAudioStreamType(AudioManager.STREAM_ALARM); player.setOnCompletionListener(mp->stopSelf()); player.start();} else stopSelf(); }
   } catch(Exception e){ stopSelf(); }
   return START_NOT_STICKY;
 }
 android.content.SharedPreferences getPreferences(){ return getSharedPreferences("noor",0); }
 @Override public void onDestroy(){ if(player!=null){try{if(player.isPlaying())player.stop();}catch(Exception ignored){} player.release();player=null;} stopForeground(true); super.onDestroy(); }
 @Override public android.os.IBinder onBind(Intent i){return null;}
}
