package com.noornamaz.app;
import android.content.*;
import android.app.*;
import android.os.Build;
public class AzanReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c, Intent i){
   String name=i.getStringExtra("name");
   Intent s=new Intent(c,AzanService.class); s.putExtra("name",name);
   if(Build.VERSION.SDK_INT>=26)c.startForegroundService(s); else c.startService(s);
   if(name!=null){
     android.content.SharedPreferences p=c.getSharedPreferences("noor_alarms",0);
     long next=p.getLong(name,0L)+86400000L;
     p.edit().putLong(name,next).apply();
     Intent again=new Intent(c,AzanReceiver.class); again.putExtra("name",name);
     PendingIntent pi=PendingIntent.getBroadcast(c,name.hashCode(),again,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
     AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
     if(Build.VERSION.SDK_INT<31 || am.canScheduleExactAlarms()){
       if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next,pi); else am.setExact(AlarmManager.RTC_WAKEUP,next,pi);
     }
   }
 }
}
