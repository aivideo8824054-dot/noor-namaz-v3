# Noor Namaz V3 (Update 1.5)

This update keeps the existing Noor Namaz interface and features, with focused changes:
- Saves the selected PIN code, State, District and Village/Post Office and restores them when the app opens again.
- Keeps the selected location coordinates and prayer calculation settings in the existing WebView local storage.
- Shows the separate Azan time below each prayer time.
- Default Azan offsets: Fajr 40 minutes before; Zuhr, Asr, Maghrib and Isha 15 minutes before. Each offset can be edited by the user.
- Schedules Android alarms using the selected offset; selecting an audio file does not play it immediately.
- Adds a Stop action to the Azan notification. Volume keys stop playback while the app Activity is in the foreground.
- Retains the existing prayer-time calculation, Qibla, Hijri/Gregorian dates, duas, tasbih and other app content.

The Android power button cannot reliably be used as an app stop control. Use the Stop action in the Azan notification, or the volume keys while the app is in the foreground.

PIN lookup requires internet access. Exact alarm permission and notification permission must be granted on supported Android versions. Background playback can also be affected by Android battery restrictions. Always compare prayer times with a trusted local mosque timetable.

Build: Android Gradle Plugin 8.6.1, compileSdk 35, Java 17, Gradle 8.9 compatible.
